VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmMain 
   Caption         =   "UserForm1"
   ClientHeight    =   13230
   ClientLeft      =   150
   ClientTop       =   585
   ClientWidth     =   24645
   OleObjectBlob   =   "frmMain.frx":0000
   StartUpPosition =   2  'CenterScreen
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


#If VBA7 And Win64 Then
    ' // 64bit
    Private Declare PtrSafe Function LoadCursorBynum Lib "user32" Alias "LoadCursorA" (ByVal hInstance As Long, ByVal lpCursorName As Long) As Long
    Private Declare PtrSafe Function SetCursor Lib "user32" (ByVal hCursor As Long) As Long
#Else
    ' // 32bit
    Private Declare Function LoadCursorBynum Lib "user32" Alias "LoadCursorA" (ByVal hInstance As Long, ByVal lpCursorName As Long) As Long
    Private Declare Function SetCursor Lib "user32" (ByVal hCursor As Long) As Long
#End If

Public NavTopBar As New clsTopBar

Private Declare PtrSafe Function ShowWindow Lib "user32" (ByVal hWnd As Long, ByVal nCmdShow As Long) As Long
Private Const SW_MAXIMIZE = 3

Private Sub btnAddPerson_Click()
    With frmPerson
        .txtID = 0
        .Show
    End With
End Sub

Private Sub btnAddCustomer_Click()
    With frmCustomer
        .id = 0
        .Show
    End With
End Sub

Private Sub Label93_Click()

End Sub

Private Sub txtSearchPerson_Change()
    product.TableDataList frmMain.txtSearchPerson, True, "ID", "ASC"
End Sub

Private Sub txtSearchCustomer_Change()
    customer.TableDataList frmMain.txtSearchCustomer, True, "ID", "ASC"
End Sub

Private Sub UserForm_Initialize()
    SortDirection = "asc"
    arrIndex = -1
    FirstRecVal = 1
    LastRecVal = 10
    PageNumber = 1
    ' #FF9900 = Orange
     TxtColor ForeColor:="#43545F", _
             EnterColor:="#005ea2", _
             TitleColor:="#ababab", _
             AlertColor:="#f72111", _
             SuccessColor:="#22ab2b"
    mp_menu.Value = 1
    tbox.clasBox Me
    Nav.CreateNavMenuLittle
    dash.DashBoardCreate
    orders.TableDataList , True, "order_id", "ASC"
    cBtn.classButton Me, mp_menu
    EnableMouseScroll Me
    Nav.SubMenuVisibleFalse
End Sub

Private Sub UserForm_Activate()
    'tbox.HideFormTitleBar Me
    Nav.SubMenuVisibleFalse

    Dim hWnd As Long
    Dim pathName As String
    
    hWnd = FindWindow("ThunderDFrame", Me.Caption) ' UserForm'un pencere baï¿½lï¿½ï¿½ï¿½na gï¿½re hWnd'yi bulun
    MakeFormResizable
    If FormLoad = False Then
        SetStandAloneForm Me, "Form"
        ShowWindow hWnd, SW_MAXIMIZE ' Pencereyi maksimize etmek iï¿½in ShowWindow API'sini kullanï¿½n
        FormLoad = True
    End If

    Call NavTopBar.AddNavTopBar(frmMain)
End Sub

Private Sub UserForm_Resize()
    Nav.FormResize
End Sub

Private Sub UserForm_Terminate()
    Set Nav = Nothing
    FormLoad = False
End Sub

Private Sub ChangeMenuThemeIcon_Click()
    Dim IconTop As Integer
    Set mForm = frmMain
    Set mFrame = frmMain.frameNavLittle
    
    IconTop = frmMain.Height - 30
    With ChangeMenuThemeIcon
        If .Caption = ChrW("&HE0FE") Then
            Do While .Top < IconTop
                DoEvents
                .Top = .Top + 0.1
            Loop
           .Caption = ChrW("&HE103")
           
            Do While .Top > IconTop - 40
                DoEvents
                .Top = .Top - 0.1
            Loop
            SetMenuTheme "Light", "E103"
           If mFrame.Name = "FrameNavBig" Then
                Nav.CreateNavMenuBig
            Else
                Nav.CreateNavMenuLittle
            End If
        Else
        
            Do While .Top < IconTop
                DoEvents
                .Top = .Top + 0.1
            Loop
           .Caption = ChrW("&HE0FE")
           
            Do While .Top > IconTop - 40
                DoEvents
                .Top = .Top - 0.1
            Loop
            SetMenuTheme "Dark", "E0FE"
            If mFrame.Name = "FrameNavBig" Then
                Nav.CreateNavMenuBig
            Else
                Nav.CreateNavMenuLittle
            End If
        End If
    End With
End Sub

