VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmPerson 
   Caption         =   "UserForm1"
   ClientHeight    =   7620
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   12930
   OleObjectBlob   =   "frmPerson.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmPerson"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Label12_Click()
    tBox.TxtControl
    If txtKontrol = True Then
        SavePerson txtID
    End If
End Sub

Private Sub Label26_Click()
    Unload Me
End Sub

Private Sub UserForm_Click()

End Sub

Private Sub UserForm_Initialize()
    '//textbox color #0070C0
    TxtColor ForeColor:="#43545F", _
                EnterColor:="#005ea2", _
                TitleColor:="#ababab", _
                AlertColor:="#f72111", _
                SuccessColor:="#22ab2b"
    tBox.clasBox Me, "Border"
    cBtn.classButton Me
    
    cbGender.List = Array("Male", "Female")
 
End Sub
