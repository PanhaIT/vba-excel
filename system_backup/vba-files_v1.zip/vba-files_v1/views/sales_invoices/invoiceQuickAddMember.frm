VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} invoiceQuickAddMember 
   Caption         =   "Quick Add Member"
   ClientHeight    =   5325
   ClientLeft      =   60
   ClientTop       =   60
   ClientWidth     =   8580.001
   OleObjectBlob   =   "invoiceQuickAddMember.frx":0000
   StartUpPosition =   2  'CenterScreen
End
Attribute VB_Name = "invoiceQuickAddMember"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Option Explicit

Private Sub UserForm_Initialize()
    '//textbox color #0070C0
    TxtColor ForeColor:="#43545F", _
                EnterColor:="#005ea2", _
                TitleColor:="#ababab", _
                AlertColor:="#f72111", _
                SuccessColor:="#22ab2b"
    tbox.clasBox Me, "Border"
    cBtn.classButton Me

End Sub

Private Sub Cancel_Click()
    invoiceQuickAddMember.member_name = ""
    invoiceQuickAddMember.telephone = ""
    invoiceQuickAddMember.address = ""
    invoiceQuickAddMember.Hide
End Sub

Private Sub save_Click()
    Dim memberName, telephone, address, id, invoiceSheet As String
    Dim i, LastRow As Long
    Dim ws As Worksheet
    Dim member_data As Range

    Set ws = Sheets("GroupMember")
    memberName = invoiceQuickAddMember.member_name
    telephone = invoiceQuickAddMember.telephone
    address = invoiceQuickAddMember.address
    invoiceSheet = ActiveSheet.Range("Curent_Invoice_No").Value

    If (memberName = "") Then
        MsgBox "Please input member name, try again."
        Exit Sub
    Else
        i = 1
        Set member_data = ws.Range("C6:H6")
        LastRow = ws.Cells(Rows.Count, "C").End(xlUp).Row + 1
        Do Until WorksheetFunction.CountA(member_data.Rows(i)) = 0
            i = i + 1 'Last row
        Loop
    
        If (i <= 9) Then
            id = "0" & i
        Else
            id = i
        End If

        member_data.Cells(i, 1) = id 'id
        member_data.Cells(i, 2) = memberName 'member name
        member_data.Cells(i, 3) = telephone 'telephone
        member_data.Cells(i, 4) = address 'address
        member_data.Cells(i, 5) = "" 'note
        member_data.Cells(i, 6) = id & "." & memberName 'member name option

        invoiceQuickAddMember.member_name = ""
        invoiceQuickAddMember.telephone = ""
        invoiceQuickAddMember.address = ""
        Sheets("AddInvoice").Range("group_member_option_select").Value = id & "." & memberName
        invoiceQuickAddMember.Hide
        MsgBox "New member " & memberName & " already saved."
        Exit Sub
    End If
End Sub

