VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} invoiceQuickAddSeller 
   Caption         =   "Quick Add Seller"
   ClientHeight    =   5415
   ClientLeft      =   60
   ClientTop       =   60
   ClientWidth     =   8535.001
   OleObjectBlob   =   "invoiceQuickAddSeller.frx":0000
   StartUpPosition =   2  'CenterScreen
End
Attribute VB_Name = "invoiceQuickAddSeller"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Option Explicit

Private Sub UserForm_Initialize()
    '//textbox color #0070C0
    TxtColor ForeColor:="#43545F", _
                EnterColor:="#005ea2", _
                TitleColor:="#ababab", _
                AlertColor:="#f72111", _
                SuccessColor:="#22ab2b"
    tbox.clasBox Me, "Border"
    cBtn.classButton Me

End Sub

Private Sub Cancel_Click()
    invoiceQuickAddSeller.seller_name = ""
    invoiceQuickAddSeller.telephone = ""
    invoiceQuickAddSeller.address = ""
    invoiceQuickAddSeller.Hide
End Sub

Private Sub save_Click()
    Dim sellerName, telephone, address, id, sellerCode, invoiceSheet As String
    Dim i, LastRow As Long
    Dim ws As Worksheet
    Dim seller_data As Range

    Set ws = Sheets("Seller")
    invoiceSheet = ActiveSheet.Range("Curent_Invoice_No").Value
    sellerName = invoiceQuickAddSeller.seller_name
    telephone = invoiceQuickAddSeller.telephone
    address = invoiceQuickAddSeller.address

    If (sellerName = "") Then
        MsgBox "Please input seller name, try again."
        Exit Sub
    Else
        i = 1
        Set seller_data = ws.Range("C7:K7")
        LastRow = ws.Cells(Rows.Count, "C").End(xlUp).Row + 1
        Do Until WorksheetFunction.CountA(seller_data.Rows(i)) = 0
            i = i + 1 'Last row
        Loop
    
        If (i <= 9) Then
            id = "00" & i
        ElseIf i > 9 & i < 100 Then
            id = "0" & i
        Else
            id = i
        End If

        sellerCode = "SSF" & "-" & id

        seller_data.Cells(i, 1) = id 'id
        seller_data.Cells(i, 2) = sellerCode 'code
        seller_data.Cells(i, 3) = sellerName 'seller name
        seller_data.Cells(i, 4) = sellerName 'seller name latin
        seller_data.Cells(i, 5) = telephone 'phone
        seller_data.Cells(i, 6) = "" 'social network link
        seller_data.Cells(i, 7) = address 'address
        seller_data.Cells(i, 8) = "" 'note
        seller_data.Cells(i, 9) = id & "." & sellerName 'member name option

        invoiceQuickAddSeller.seller_name = ""
        invoiceQuickAddSeller.telephone = ""
        invoiceQuickAddSeller.address = ""
        Sheets("AddInvoice").Range("c_inv_sale_id").Value = id & "." & sellerName
        invoiceQuickAddSeller.Hide
        MsgBox "New seller " & sellerName & " already saved."
        Exit Sub
    End If
End Sub

