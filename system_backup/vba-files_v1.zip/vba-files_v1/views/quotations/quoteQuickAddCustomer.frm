VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} quoteQuickAddCustomer 
   Caption         =   "Add New Customer"
   ClientHeight    =   5655
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   8955.001
   OleObjectBlob   =   "quoteQuickAddCustomer.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "quoteQuickAddCustomer"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Option Explicit

Private Sub Cancel_Click()
    quoteQuickAddCustomer.customer_name_kh = ""
    quoteQuickAddCustomer.customer_name_en = ""
    quoteQuickAddCustomer.telephone = ""
    quoteQuickAddCustomer.address = ""
    quoteQuickAddCustomer.Hide
End Sub

Private Sub label_latin_Change()

End Sub

Private Sub save_Click()
    Dim customerNameKh, customerNameEn, telephone, address, customerCode, id, cellId As String
    Dim i, LastRow As Long
    Dim ws As Worksheet
    Dim customer_data As Range
    Dim answer As VbMsgBoxResult

    Set ws = Sheets("CustomerList")
    customerNameKh = quoteQuickAddCustomer.customer_name_kh
    customerNameEn = quoteQuickAddCustomer.customer_name_en
    telephone = quoteQuickAddCustomer.telephone
    address = quoteQuickAddCustomer.address

    If (customer_name_kh = "" Or customer_name_en = "") Then
        MsgBox "Please input customer name, try again."
        Exit Sub
    Else
        i = 1
        Set customer_data = ws.Range("C5:M5")
        LastRow = ws.Cells(Rows.Count, "C").End(xlUp).Row + 1
        Do Until WorksheetFunction.CountA(customer_data.Rows(i)) = 0
            i = i + 1 'Last row
        Loop
    
        id = "0" & i
        customerCode = "CSF" & MID(Year(Now()), 3, 4) & "-" & id
        cellId = "C" & LastRow

        customer_data.Cells(i, 1) = id 'id
        customer_data.Cells(i, 2) = customerCode 'customer code
        customer_data.Cells(i, 3) = "General" 'customer company
        customer_data.Cells(i, 4) = customerNameKh 'customer name kh
        customer_data.Cells(i, 5) = customerNameEn 'customer name en
        customer_data.Cells(i, 6) = telephone 'telephone
        customer_data.Cells(i, 7) = "" 'social network link
        customer_data.Cells(i, 8) = address 'address
        customer_data.Cells(i, 9) = "=IF(SUMIF(SaleInvoiceData!$J$6:$J$5000," & cellId & ",SaleInvoiceData!$P$6:$P$5000)*1>0,SUMIF(SaleInvoiceData!$J$6:$J$5000," & cellId & ",SaleInvoiceData!$P$6:$P$5000),0)" 'total balance
        customer_data.Cells(i, 10) = 1 'status
        customer_data.Cells(i, 11) = id & "." & customerNameKh & " (" & customerNameEn & ")" 'customer name option
        quoteQuickAddCustomer.customer_name_en = ""
        quoteQuickAddCustomer.customer_name_kh = ""
        quoteQuickAddCustomer.telephone = ""
        quoteQuickAddCustomer.address = ""
        Sheets("AddQuotation").Range("quote_customer").Value = id & "." & customerNameKh & " (" & customerNameEn & ")"
        quoteQuickAddCustomer.Hide
        MsgBox "New customer " & customerCode & " already saved."
        Exit Sub
    End If
End Sub

Private Sub UserForm_Initialize()
    TxtColor ForeColor:="#43545F", _
        EnterColor:="#005ea2", _
        TitleColor:="#ababab", _
        AlertColor:="#f72111", _
        SuccessColor:="#22ab2b"
    tbox.clasBox Me, "Border"
    cBtn.classButton Me
End Sub