VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} quoteQuickAddSeller 
   Caption         =   "Add New Seller Quote"
   ClientHeight    =   5205
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   8160
   OleObjectBlob   =   "quoteQuickAddSeller.frx":0000
   StartUpPosition =   2  'CenterScreen
End
Attribute VB_Name = "quoteQuickAddSeller"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Option Explicit

Private Sub Cancel_Click()
    quoteQuickAddSeller.seller_name = ""
    quoteQuickAddSeller.telephone = ""
    quoteQuickAddSeller.address = ""
    quoteQuickAddSeller.Hide
End Sub

Private Sub save_Click()
    Dim sellerName, telephone, address, id, sellerCode As String
    Dim i, LastRow As Long
    Dim ws As Worksheet
    Dim seller_data As Range

    Set ws = Sheets("Seller")
    sellerName = quoteQuickAddSeller.seller_name
    telephone = quoteQuickAddSeller.telephone
    address = quoteQuickAddSeller.address

    If (sellerName = "") Then
        MsgBox "Please input seller name, try again."
        Exit Sub
    Else
        i = 1
        Set seller_data = ws.Range("C7:K7")
        LastRow = ws.Cells(Rows.Count, "C").End(xlUp).Row + 1
        Do Until WorksheetFunction.CountA(seller_data.Rows(i)) = 0
            i = i + 1 'Last row
        Loop
    
        If (i <= 9) Then
            id = "00" & i
        ElseIf i > 9 & i < 100 Then
            id = "0" & i
        Else
            id = i
        End If

        sellerCode = "SSF" & "-" & id

        seller_data.Cells(i, 1) = id 'id
        seller_data.Cells(i, 2) = sellerCode 'code
        seller_data.Cells(i, 3) = sellerName 'seller name
        seller_data.Cells(i, 4) = sellerName 'seller name latin
        seller_data.Cells(i, 5) = telephone 'phone
        seller_data.Cells(i, 6) = "" 'social network link
        seller_data.Cells(i, 7) = address 'address
        seller_data.Cells(i, 8) = "" 'note
        seller_data.Cells(i, 9) = id & "." & sellerName 'member name option

        quoteQuickAddSeller.seller_name = ""
        quoteQuickAddSeller.telephone = ""
        quoteQuickAddSeller.address = ""
        Sheets("AddQuotation").Range("quote_creator").Value = id & "." & sellerName
        quoteQuickAddSeller.Hide
        MsgBox "New seller " & sellerName & " already saved."
        Exit Sub
    End If
End Sub

Private Sub UserForm_Initialize()
    TxtColor ForeColor:="#43545F", _
        EnterColor:="#005ea2", _
        TitleColor:="#ababab", _
        AlertColor:="#f72111", _
        SuccessColor:="#22ab2b"
    tbox.clasBox Me, "Border"
    cBtn.classButton Me
End Sub