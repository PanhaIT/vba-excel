VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} quoteQuickAddShipTo 
   Caption         =   "Add New Ship To"
   ClientHeight    =   4260
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   8580.001
   OleObjectBlob   =   "quoteQuickAddShipTo.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "quoteQuickAddShipTo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Option Explicit

Private Sub Cancel_Click()
    quoteQuickAddShipTo.telephone = ""
    quoteQuickAddShipTo.address = ""
    quoteQuickAddShipTo.Hide
End Sub

Private Sub save_Click()
    Dim shipToCode, telephone, address As String
    Dim i, LastRow As Long
    Dim ws As Worksheet
    Dim ship_to_data As Range

    Set ws = Sheets("ShipTo")
    telephone = quoteQuickAddShipTo.telephone
    address = quoteQuickAddShipTo.address

    If (address = "") Then
        MsgBox "Please input address, try again."
        Exit Sub
    Else
        i = 1
        Set ship_to_data = ws.Range("C6:G6")
        LastRow = ws.Cells(Rows.Count, "C").End(xlUp).Row + 1
        Do Until WorksheetFunction.CountA(ship_to_data.Rows(i)) = 0
            i = i + 1 'Last row
        Loop

        shipToCode = PadStr(i, 5, "0", xlHAlignRight) 'PadStr call from declareFunction

        ship_to_data.Cells(i, 1) = i 'id
        ship_to_data.Cells(i, 2) = "ST" & shipToCode 'code
        ship_to_data.Cells(i, 3) = address 'address name
        ship_to_data.Cells(i, 4) = 1 'status
        ship_to_data.Cells(i, 5) = address 'member name option

        'reset dialog
        quoteQuickAddShipTo.telephone = ""
        quoteQuickAddShipTo.address = ""
        Sheets("AddQuotation").Range("quote_ship_to").Value = address

        quoteQuickAddShipTo.Hide
        MsgBox "New shipment address already saved."
        Exit Sub
    End If
End Sub

Private Sub UserForm_Initialize()
    TxtColor ForeColor:="#43545F", _
        EnterColor:="#005ea2", _
        TitleColor:="#ababab", _
        AlertColor:="#f72111", _
        SuccessColor:="#22ab2b"
    tbox.clasBox Me, "Border"
    cBtn.classButton Me
End Sub