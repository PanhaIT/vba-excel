Attribute VB_Name = "quotation"

Public Sub printQuoteLetterHead()
  ActiveSheet.Range("quote_print_letter_head").PrintPreview
End Sub

Public Sub printQuoteNoLetterHead()
  ActiveSheet.Range("quote_print_no_letter_head").PrintPreview
End Sub

Public Sub copyPrintLetterHead()
   'quote_copy_print_letter_head
   Sheets("AddQuotation").Range("quote_print_letter_head").Copy
   Sheets("AddQuotation").Range("quote_print_letter_head").select
End Sub

Public Sub copyPrintNoLetterHead()
   'quote_copy_print_no_letter_head
   ActiveSheet.Range("quote_print_no_letter_head").Copy
   ActiveSheet.Range("quote_print_no_letter_head").select
End Sub

Public Sub AddQuotation()
   ' define variable quotation
   Dim branchId, customerId, customerName,quoteServiceType, quoteCode, currencyId, priceTypeId, shipTo, shipTel,createdBy AS String
   Dim quoteId, companyId, totalVat, vatPercent, vatSettingId, vatCal, discount, disPercent, totalAmount, totalDeposit, isClose, isApprove As Integer
   Dim status, quoteWeek, quoteMonth, quoteYear,vatCalculateId, lastQuoteRowId As Integer
   Dim quoteDate, approveDate, createdDate As Date
   
   ' define variable quotation detail
   Dim discountAmount, discountPercent, unitCost, unitPrice, totalPrice, quoteDetailId, conversion, qty, qtyFree, discountTypeId, itemDiscount As Integer
   Dim productId, productCode, productName, uom, qtyUomId, discountId, productUoM, productUoMId AS String
   Dim totalDisPrice,totalAmountBfDis,totalDisItem As Double

   ' general define
   Dim quoteData, quoteDetailData, quoteItemRow AS Range
   Dim ws_quote , ws_quote_detail AS Worksheet
   Dim confirmDialog AS VbMsgBoxResult

   Set ws_quote         = Sheets("QuoteData")
   Set ws_quote_detail  = Sheets("QuoteDetailData")
   confirmDialog        = MsgBoxW("Are you want to save this quotation?", vbYesNoCancel  +  vbQuestion + vbDefaultButton1, "Add New Quotation")

   companyId            = "1"
   branchId             = MID(ActiveSheet.Range("quote_branch").value,1,2)
   customerId           = MID(ActiveSheet.Range("quote_customer").value,1,4)
   customerName         = MID(ActiveSheet.Range("quote_customer").value,6,100)
   quoteCode            = ActiveSheet.Range("quote_code").value
   ' quoteId              = ActiveSheet.Range("quote_id").value
   quoteDate            = Format(ActiveSheet.Range("quote_date").Value, "yyyy/mm/dd")
   quoteServiceType     = ActiveSheet.Range("quote_service_type").value
   shipTo               = ActiveSheet.Range("quote_ship_to").value
   shipTel              = ActiveSheet.Range("quote_ship_telephone").value
   createdDate          = Format(Now(), "yyyy/mm/dd hh:mm:ss")
   createdBy            = ActiveSheet.Range("quote_creator").value
   moduleTypeId         = "016"
   currencyId           = ActiveSheet.Range("quote_currency_id").value
   priceTypeId          = ActiveSheet.Range("quote_price_type_id").value

   If (ActiveSheet.Range("quote_dis_option").value<>"") Then
      discountTypeId    = MID(ActiveSheet.Range("quote_dis_option").value,1,1) * 1
   Else
      discountTypeId	   = ""
   End If

   Run resetWorkSheetsFilter()
   
   subTotalAmount       = ActiveSheet.Range("quote_sub_total_amount").value
   totalDiscount        = ActiveSheet.Range("quote_discount").value
   totalAmount          = ActiveSheet.Range("quote_total_amount").value
   discountAmount       = ActiveSheet.Range("quote_dis_amount").value
   discountPercent      = ActiveSheet.Range("quote_dis_percent").value
   totalAmountBfDis     = ActiveSheet.Range("quote_total_price_bf_discount").value
   totalDisItem         = ActiveSheet.Range("quote_total_dis_item_free").value

   vatCal               = ActiveSheet.Range("quote_vat_cal_id").value
   vatPercent           = ActiveSheet.Range("quote_vat_percent").value
   vatSettingId         = MID(ActiveSheet.Range("quote_vat").value,1,2) 'vat setting id
   totalVat             = ActiveSheet.Range("quote_total_vat").value
   totalDeposit         = 0
   quoteWeek            = ActiveSheet.Range("quote_week").value

   isApprove            = 1 '0:approved,1:not approve
   isClose              = 0 '0:close,1:open
   status               = 1 '0:inactive,1:active
   approveDate          = ""
   approvedBy           = ""

   'insert to quotation data
   Set quoteData        = ws_quote.Range("C8:AH8")
   quoteId              = ws_quote.Cells(Rows.Count, "C").End(xlUp).Row - 6

   If (discountTypeId=1) Then 'discount amount
      discountPercent = 0
   ElseIf (discountTypeId=2) Then 'discount percent
      discountAmount  = 0
   Else 'no discount
      discountAmount  = 0
      discountPercent = 0
   End If

   If (quoteCode="" OR quoteDate="" OR branchId="" OR customerId="" OR quoteServiceType="" OR createdBy="" OR totalAmountBfDis="" OR totalAmountBfDis=0 OR subTotalAmount<0) Then
      MsgBox "Select/input require field, please try again."
      exit sub
   Else
      If (confirmDialog=vbYes) Then
         quoteMonth           = month(quoteDate)
         quoteYear            = year(quoteDate)
         quoteData.Cells(quoteId,1)   = quoteId 'id
         quoteData.Cells(quoteId,2)   = quoteCode 'quote code
         quoteData.Cells(quoteId,3)   = quoteDate 'quote date
         quoteData.Cells(quoteId,4)   = companyId 'company id
         quoteData.Cells(quoteId,5)   = branchId 'branch id
         quoteData.Cells(quoteId,6)   = customerId 'customer id
         quoteData.Cells(quoteId,7)   = customerName 'customer name
         quoteData.Cells(quoteId,8)   = quoteServiceType 'service type
         quoteData.Cells(quoteId,9)   = currencyId 'currency id
         quoteData.Cells(quoteId,10)  = priceTypeId 'price type id

         quoteData.Cells(quoteId,11)  = vatPercent 'vat percent
         quoteData.Cells(quoteId,12)  = vatSettingId 'vat setting id
         quoteData.Cells(quoteId,13)  = vatCal 'vat calculate before and after discount
         quoteData.Cells(quoteId,14)  = discountAmount 'discount amount
         quoteData.Cells(quoteId,15)  = discountPercent 'discount percent

         quoteData.Cells(quoteId,16)  = subTotalAmount 'sub total
         quoteData.Cells(quoteId,17)  = totalVat 'total vat
         quoteData.Cells(quoteId,18)  = totalDiscount 'total discount
         quoteData.Cells(quoteId,19)  = totalDeposit 'total deposit
         quoteData.Cells(quoteId,20)  = totalAmount 'total amount

         quoteData.Cells(quoteId,21)  = shipTo 'ship to
         quoteData.Cells(quoteId,22)  = shipTel 'ship telephone
         quoteData.Cells(quoteId,23)  = createdDate 'created
         quoteData.Cells(quoteId,24)  = createdBy 'created by
         quoteData.Cells(quoteId,25)  = approveDate 'approved
         quoteData.Cells(quoteId,26)  = approvedBy 'approved by
         quoteData.Cells(quoteId,27)  = isClose 'is close
         quoteData.Cells(quoteId,28)  = isApprove 'is approve
         quoteData.Cells(quoteId,29)  = status 'status
         quoteData.Cells(quoteId,30)  = quoteWeek 'week
         quoteData.Cells(quoteId,31)  = quoteMonth 'month
         quoteData.Cells(quoteId,32)  = quoteYear 'year

         If (totalAmountBfDis>0) Then
            Set quoteDetailData      = ws_quote_detail.Range("C8:Z8")
            quoteDetailId            = ws_quote_detail.Cells(Rows.Count, "C").End(xlUp).Row - 6

            Set quoteItemRow         = ActiveSheet.Range("I8:V87")

            For a = 1 To quoteItemRow.Rows.Count
               If quoteItemRow.Cells(a,1) <> "" Then

                  productId      = quoteItemRow.Cells(a,1)
                  productCode    = quoteItemRow.Cells(a,3)
                  productName    = quoteItemRow.Cells(a,5)
                  qty            = ConvertToInteger(quoteItemRow.Cells(a, 6))
                  qtyFree        = ConvertToInteger(quoteItemRow.Cells(a, 7))
                  productUoM     = MID(quoteItemRow.Cells(a,8),4,50)
                  productUoMId   = MID(quoteItemRow.Cells(a,8),1,2)
                  unitPrice      = quoteItemRow.Cells(a,10)
                  itemDiscount   = quoteItemRow.Cells(a,12)
                  totalPrice     = quoteItemRow.Cells(a,14)
                  conversion     = quoteItemRow.Cells(a,15)
                  totalDisPrice  = quoteItemRow.Cells(a,16)
                  unitCost	      = quoteItemRow.Cells(a,17)

                  quoteDetailData.Cells(quoteDetailId, 1)   = quoteDetailId 'id
                  quoteDetailData.Cells(quoteDetailId, 2)   = quoteId 'quote id
                  quoteDetailData.Cells(quoteDetailId, 3)   = quoteCode 'quote number
                  quoteDetailData.Cells(quoteDetailId, 4)   = quoteDate 'quote date
                  quoteDetailData.Cells(quoteDetailId, 5)   = customerId 'customer id
                  quoteDetailData.Cells(quoteDetailId, 6)   = productId 'product id
                  quoteDetailData.Cells(quoteDetailId, 7)   = productCode 'barcode product
                  quoteDetailData.Cells(quoteDetailId, 8)   = productName 'item description/service
                  quoteDetailData.Cells(quoteDetailId, 9)   = qty 'qty
                  quoteDetailData.Cells(quoteDetailId, 10)  = qtyFree 'qty free
                  quoteDetailData.Cells(quoteDetailId, 11)  = productUoM 'uom
                  quoteDetailData.Cells(quoteDetailId, 12)  = productUoMId 'uom id
                  quoteDetailData.Cells(quoteDetailId, 13)  = conversion 'uom conversion
                  quoteDetailData.Cells(quoteDetailId, 14)  = "" 'discount id
                  quoteDetailData.Cells(quoteDetailId, 15)  = itemDiscount 'discount amount
                  quoteDetailData.Cells(quoteDetailId, 16)  = "" 'discount percent
                  quoteDetailData.Cells(quoteDetailId, 17)  = unitCost 'unit cost
                  quoteDetailData.Cells(quoteDetailId, 18)  = unitPrice 'unit price
                  quoteDetailData.Cells(quoteDetailId, 19)  = totalDisPrice 'discount total price
                  quoteDetailData.Cells(quoteDetailId, 20)  = totalPrice 'total price
                  quoteDetailData.Cells(quoteDetailId, 21)  = 1 'status
                  quoteDetailData.Cells(quoteDetailId, 22)  = quoteWeek 'week
                  quoteDetailData.Cells(quoteDetailId, 23)  = quoteMonth 'month
                  quoteDetailData.Cells(quoteDetailId, 24)  = quoteYear 'year
                  quoteDetailId = quoteDetailId + 1
               End If
            Next a
         Else
            exit sub
         End If

         resetQuote(obj)
         ws_quote.Select
         lastQuoteRowId = ActiveSheet.Cells(Rows.Count, "C").End(xlUp).Row
         ActiveSheet.Range("C"& lastQuoteRowId & ":" & "AH" & lastQuoteRowId).Select 'select new insert quotation row
         MsgBox "Quotation " & quoteCode & " saved successful."
         exit sub
      Else
         exit sub
      End If
   End If
End Sub

Private Sub todayPickerDate()
   ActiveSheet.Range("quote_date").Value = Format(Now(), "yyyy/mm/dd")
End Sub

Private Function resetQuote(obj)
   ActiveSheet.Range("quote_no").value = ActiveSheet.Range("quote_no").value + 1
   ActiveSheet.Range("quote_column_product").value = ""
   ActiveSheet.Range("M8").value = ActiveSheet.Range("P92").value
   ActiveSheet.Range("quote_letter_head_qrcode").value = ""
   ActiveSheet.Range("quote_no_letter_head_qrcode").value = ""
   ActiveSheet.Range("quote_date").Value = ""
   ActiveSheet.Range("quote_customer").Value = ActiveSheet.Range("F11").value
   ActiveSheet.Range("quote_service_type").Value = ""
   ActiveSheet.Range("quote_ship_to").Value = ""
   ' ActiveSheet.Range("quote_ship_telephone").Value = ""
   ActiveSheet.Range("quote_note").Value = ""
   ActiveSheet.Range("quote_qty").Value = ""
   ActiveSheet.Range("quote_qty_free").Value = ""
   ActiveSheet.Range("quote_discount_by_item").Value = ""
   ActiveSheet.Range("quote_vat").Value = ActiveSheet.Range("R90").Value
End Function

Private Sub addCustomer()
   Run resetWorkSheetsFilter()
   quoteQuickAddCustomer.Show
End Sub

Private Sub addSeller()
   Run resetWorkSheetsFilter()
   quoteQuickAddSeller.Show
End Sub

Private Sub addShipTo()
   Run resetWorkSheetsFilter()
   quoteQuickAddShipTo.Show
End Sub

Private Sub cancelClickQuoteQuickAddCustomer()
    quoteQuickAddCustomer.customer_name_kh = ""
    quoteQuickAddCustomer.customer_name_en = ""
    quoteQuickAddCustomer.telephone = ""
    quoteQuickAddCustomer.address = ""
    quoteQuickAddCustomer.Hide
End Sub

Private Sub saveClickQuoteQuickAddCustomer()
    Dim customerNameKh, customerNameEn, telephone, address, customerCode, id, cellId As String
    Dim i, LastRow As Long
    Dim ws As Worksheet
    Dim customer_data As Range
    Dim answer As VbMsgBoxResult

    Set ws = Sheets("CustomerList")
    customerNameKh = quoteQuickAddCustomer.customer_name_kh
    customerNameEn = quoteQuickAddCustomer.customer_name_en
    telephone = quoteQuickAddCustomer.telephone
    address = quoteQuickAddCustomer.address

    If (customer_name_kh = "" Or customer_name_en = "") Then
        MsgBox "Please input customer name, try again."
        Exit Sub
    Else
        i = 1
        Set customer_data = ws.Range("C5:M5")
        LastRow = ws.Cells(Rows.Count, "C").End(xlUp).Row + 1
        Do Until WorksheetFunction.CountA(customer_data.Rows(i)) = 0
            i = i + 1 'Last row
        Loop
    
        id = "0" & i
        customerCode = "CSF" & MID(Year(Now()), 3, 4) & "-" & id
        cellId = "C" & LastRow

        customer_data.Cells(i, 1) = id 'id
        customer_data.Cells(i, 2) = customerCode 'customer code
        customer_data.Cells(i, 3) = "General" 'customer company
        customer_data.Cells(i, 4) = customerNameKh 'customer name kh
        customer_data.Cells(i, 5) = customerNameEn 'customer name en
        customer_data.Cells(i, 6) = telephone 'telephone
        customer_data.Cells(i, 7) = "" 'social network link
        customer_data.Cells(i, 8) = address 'address
        customer_data.Cells(i, 9) = "=IF(SUMIF(SaleInvoiceData!$J$6:$J$5000," & cellId & ",SaleInvoiceData!$P$6:$P$5000)*1>0,SUMIF(SaleInvoiceData!$J$6:$J$5000," & cellId & ",SaleInvoiceData!$P$6:$P$5000),0)" 'total balance
        customer_data.Cells(i, 10) = 1 'status
        customer_data.Cells(i, 11) = id & "." & customerNameKh & " (" & customerNameEn & ")" 'customer name option
        quoteQuickAddCustomer.customer_name_en = ""
        quoteQuickAddCustomer.customer_name_kh = ""
        quoteQuickAddCustomer.telephone = ""
        quoteQuickAddCustomer.address = ""
        Sheets("AddQuotation").Range("quote_customer").Value = id & "." & customerNameKh & " (" & customerNameEn & ")"
        quoteQuickAddCustomer.Hide
        MsgBox "New customer " & customerCode & " already saved."
        Exit Sub
    End If
End Sub

Private Sub cancelClickQuoteQuickAddSeller()
    quoteQuickAddSeller.seller_name = ""
    quoteQuickAddSeller.telephone = ""
    quoteQuickAddSeller.address = ""
    quoteQuickAddSeller.Hide
End Sub

Private Sub saveClickQuoteQuickAddSeller()
    Dim sellerName, telephone, address, id, sellerCode As String
    Dim i, LastRow As Long
    Dim ws As Worksheet
    Dim seller_data As Range

    Set ws = Sheets("Seller")
    sellerName = quoteQuickAddSeller.seller_name
    telephone = quoteQuickAddSeller.telephone
    address = quoteQuickAddSeller.address

    If (sellerName = "") Then
        MsgBox "Please input seller name, try again."
        Exit Sub
    Else
        i = 1
        Set seller_data = ws.Range("C7:K7")
        LastRow = ws.Cells(Rows.Count, "C").End(xlUp).Row + 1
        Do Until WorksheetFunction.CountA(seller_data.Rows(i)) = 0
            i = i + 1 'Last row
        Loop
    
        If (i <= 9) Then
            id = "00" & i
        ElseIf i > 9 & i < 100 Then
            id = "0" & i
        Else
            id = i
        End If

        sellerCode = "SSF" & "-" & id

        seller_data.Cells(i, 1) = id 'id
        seller_data.Cells(i, 2) = sellerCode 'code
        seller_data.Cells(i, 3) = sellerName 'seller name
        seller_data.Cells(i, 4) = sellerName 'seller name latin
        seller_data.Cells(i, 5) = telephone 'phone
        seller_data.Cells(i, 6) = "" 'social network link
        seller_data.Cells(i, 7) = address 'address
        seller_data.Cells(i, 8) = "" 'note
        seller_data.Cells(i, 9) = id & "." & sellerName 'member name option

        quoteQuickAddSeller.seller_name = ""
        quoteQuickAddSeller.telephone = ""
        quoteQuickAddSeller.address = ""
        Sheets("AddQuotation").Range("quote_creator").Value = id & "." & sellerName
        quoteQuickAddSeller.Hide
        MsgBox "New seller " & sellerName & " already saved."
        Exit Sub
    End If
End Sub