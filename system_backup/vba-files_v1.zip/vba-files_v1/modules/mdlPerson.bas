Attribute VB_Name = "mdlPerson"
Sub SavePerson(PersonId As Integer)
    With frmPerson
        Connect
        SQL = "Select * from tbl_Person"
        '//When Person Update
        If PersonId > 0 Then SQL = SQL & " where ID= " & PersonId
        '//open recordset
        rs.Open SQL, cn, 1, 3
        
        If Not rs.EOF Or rs.BOF Then     
            '//When Person add
            If PersonId = 0 Then rs.AddNew
                rs!FirstName = .txtFirstName
                rs!LastName = .txtLastName
                rs!Email = .txtEmail
                rs!Phone = .txtPhone
                rs!Gender = .cbGender
                rs!BirthDate = .txtBirthDate
                
                '//This is how we need to write in non-mandatory fields
                If .txtJob <> "" Then rs!Job = .txtJob
                If .txtCity <> "" Then rs!City = .txtCity
                
                rs.Update
            If PersonId = 0 Then MsgBox "Person Added!"
            If PersonId > 0 Then MsgBox "Person Updated!"
            product.TableDataList frmMain.txtSearchPerson, True, "ID", "ASC"
        End If
    End With
End Sub
