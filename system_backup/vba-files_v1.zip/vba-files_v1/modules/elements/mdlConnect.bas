Attribute VB_Name = "mdlConnect"
Public rs As New ADODB.Recordset
Public cn As New ADODB.Connection

Public SQL As String

Sub Connect()
    Set cn = New ADODB.Connection
    Set rs = New ADODB.Recordset
' D:\1_Documents\1_Companies\kscm_report\config
    With cn
        .Provider = "Microsoft.ACE.OLEDB.12.0"
        ' .ConnectionString = "Data Source = " & ThisWorkbook.Path & "\config\kscm.accdb" 'db.accdb
        ' D:\1_Documents\1_Companies\kscm_report\database
        .ConnectionString = "Data Source =D:\OneDrive\YBA ADVISORY\B-Clients and Services\C024-KOK SNUOL\ks_system\database\kscm.accdb" 'db.accdb
        .Open cn
    End With
End Sub

Sub Disconnect()
    Set rs = Nothing
    Set cn = Nothing
End Sub

Public Sub OpenSystem()
    frmMain.Show
End Sub