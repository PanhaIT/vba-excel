Attribute VB_Name = "receivePayment"

Sub SaveReceivePayment()
    Dim LastRowSaleInvoiceDate As Long
    Dim sheetNo,statusNote,receiptNo As String
    Dim indexColor,statusInvoice,invoiceNo,incomeId As Integer
    Dim totalAmountDue,totalDiscountKh,totalLastDiscount,totalAmountPaidKh,totalAmountPaidUsd,totalAmountPaid,totalAmountPaidBefore,totalBalance AS Double
    Dim answer AS VbMsgBoxResult

    Set ws = Sheets("SaleInvoiceData")
    Set rp = Sheets("ReceivePayment")
    answer = MsgBox("Are you want to save this payment " & invoiceSheeet & " ?", vbYesNoCancel + vbQuestion + vbDefaultButton1, "Receive Payment")

    receiptNo            = rp.Range("rp_receipt_code").Value
    sheetNo              = rp.Range("rp_invoice_sheet_no").Value
    invoiceNo            = rp.Range("c_rp_invoice_no").Value
    invoiceDate          = rp.Range("rp_invoice_date").Value
    paidDate             = rp.Range("c_rp_current_date").Value
    customerName         = rp.Range("rp_customer_name").Value
    expenseType          = rp.Range("rp_expense_type").Value
    incomeType           = rp.Range("rp_option_income_from").Value
    branchName           = rp.Range("rp_option_income_type").Value

    customerId           = rp.Range("c_rp_customer_id").Value
    expenseTypeId        = "003"
    incomeTypeId         = rp.Range("rp_income_id").Value
    branchId             = MID(rp.Range("rp_option_income_type").Value,1,2)
    saleId               = rp.Range("rp_recipient_option").Value

    salesInvoiceNote     = rp.Range("c_rp_description").Value
    invoiceWeek          = rp.Range("rp_week").Value
    invoiceMonth         = MONTH(rp.Range("c_rp_current_date").Value)
    invoiceYear          = YEAR(rp.Range("c_rp_current_date").Value)

    totalAmountDue       = rp.Range("rp_amount_due").Value
    totalAmountPaid      = rp.Range("rp_total_amount_paid").Value
    totalAmountPaidBefore= rp.Range("rp_amount_paid_befor").Value
    totalAmountPaidKh    = rp.Range("c_rp_amount_kh_paid").Value
    totalAmountPaidUsd   = rp.Range("c_rp_amount_en_paid").Value
    totalDiscountKh      = rp.Range("c_rp_discount").Value
    totalLastDiscount    = rp.Range("rp_last_discount").Value
    totalBalance         = rp.Range("rp_total_balance").Value

    Run resetWorkSheetsFilter()
    If totalAmountPaid > totalAmountDue Then
        MsgBox "Total amount paid is bigger than total amount due, please try again."
        Exit Sub
    ElseIf (totalAmountPaid + totalDiscountKh) > totalAmountDue Then
        MsgBox "Total amount paid and discount are bigger than total amount due, please try again."
        Exit Sub
    End If

    'Sales Invoice Status=> -1 = Edit, 1  = issue, 2  = fullfilied ,3  = partial
    If totalBalance = 0 Then
        statusInvoice = 2
        indexColor    = 43
    ElseIf totalAmountDue > (totalAmountPaid + totalDiscountKh) and (totalAmountPaid + totalDiscountKh) > 0 Then
        statusInvoice = 3
        indexColor    = 44
    ElseIf totalBalance = totalAmountDue Then
        statusInvoice = 1
        indexColor    = 3
    Else
        statusInvoice = -1
        indexColor    = 1
    End If

    If ActiveSheet.Range("c_rp_status").Value = 2 Then
        MsgBox "Receive payment already saved."
        Exit Sub
    ElseIf saleId = "" Or ActiveSheet.Range("c_rp_module_types_option").Value = "" Or ActiveSheet.Range("c_rp_current_date").Value = "" Or ActiveSheet.Range("c_rp_invoice_no").Value = "" Or ActiveSheet.Range("rp_option_income_from").Value = "" Or ActiveSheet.Range("rp_option_income_type").Value = "" And (ActiveSheet.Range("c_rp_amount_en_paid") = 0 Or ActiveSheet.Range("c_rp_amount_kh_paid").Value = 0 Or totalDiscountKh = 0) Then
        MsgBox "Please select or input require field, try again."
        Exit Sub
    Else
        If answer = vbYes Then
            '*******Start save amount paid*******
            If totalAmountPaid > 0 And saleId <> "" Then
                Dim i As Long
                Dim ic_data As Range 'ic_data : income date

                i = 1
                Set ic_data = Sheets("IncomeData").Range("B5:W5")
                Do Until WorksheetFunction.CountA(ic_data.Rows(i)) = 0
                    i = i + 1
                Loop

                ic_data.Cells(i,1)  = invoiceNo*1 'invoice no.
                ic_data.Cells(i,2)  = invoiceDate 'invoice date
                ic_data.Cells(i,3)  = "020" 'module type id
                ic_data.Cells(i,4)  = branchId 'branch id
                ic_data.Cells(i,5)  = incomeTypeId 'income type id
                ic_data.Cells(i,6)  = saleId 'sale id
                ic_data.Cells(i,7)  = customerId 'customer id
                ic_data.Cells(i,8)  = paidDate 'paid date
                ic_data.Cells(i,9)  = receiptNo 'receipt no.
                ic_data.Cells(i,10) = branchName 'branch name
                ic_data.Cells(i,11) = incomeType 'income type
                ic_data.Cells(i,12) = salesInvoiceNote 'description 
                ic_data.Cells(i,13) = customerName 'customer name

                ic_data.Cells(i,14) = totalAmountDue 'amount due
                ic_data.Cells(i,15) = totalAmountPaidKh 'amount paid riel
                ic_data.Cells(i,16) = totalAmountPaidUsd 'amount paid dollar
                ic_data.Cells(i,17) = totalAmountPaid 'total amount
                ic_data.Cells(i,18) = totalDiscountKh 'discount
                ic_data.Cells(i,19) = totalBalance 'balance

                ic_data.Cells(i,20) = invoiceWeek 'week
                ic_data.Cells(i,21) = invoiceMonth 'month
                ic_data.Cells(i,22) = invoiceYear 'year
            End If
            '*******End save amount paid*******

            '*******Start save invoice discount*******
            If totalDiscountKh > 0 Then
                Dim k As Long
                Dim oex_data As Range

                k = 1
                Set oex_data = Sheets("ExpenseData").Range("B5:S5")
                Do Until WorksheetFunction.CountA(oex_data.Rows(k)) = 0
                    k = k + 1
                Loop
                oex_data.Cells(k,1)  = invoiceNo*1 'invoice no.
                oex_data.Cells(k,2)  = invoiceDate 'Paid date
                oex_data.Cells(k,3)  = "05" 'module type id
                oex_data.Cells(k,4)  = branchId 'branch id
                oex_data.Cells(k,5)  = expenseTypeId 'expense type id
                oex_data.Cells(k,6)  = customerId 'customer id
                oex_data.Cells(k,7)  = " " 'vendor id
                oex_data.Cells(k,8)  = " " 'member id
                oex_data.Cells(k,9)  = branchName 'branch name
                oex_data.Cells(k,10) = expenseType 'expense type name
                oex_data.Cells(k,11) = " " 'description
                oex_data.Cells(k,12) = invoiceNo 'reference invoice code
                oex_data.Cells(k,13) = totalDiscountKh 'amount paid kh
                oex_data.Cells(k,14) = 0 'amount paid usd
                oex_data.Cells(k,15) = salesInvoiceNote 'remark

                oex_data.Cells(k,16) = invoiceWeek 'week
                oex_data.Cells(k,17) = invoiceMonth 'month
                oex_data.Cells(k,18) = invoiceYear 'year
            End If
            '*******End save invoice discount*******

            '*******update amount paid,discount,balance and status sales invoice*******
            LastRowSaleInvoiceDate = ws.Cells(Rows.Count, "C").End(xlUp).Row 
            For j = 6 To LastRowSaleInvoiceDate
                If ws.Cells(j, 3).Value * 1 = invoiceNo * 1 Then
                    ws.Cells(j,14) = totalDiscountKh + totalLastDiscount  'total discount
                    ws.Cells(j,15) = totalAmountPaid + totalAmountPaidBefore 'total amount paid
                    ws.Cells(j,16) = totalBalance 'balance
                    ws.Cells(j,18) = statusInvoice 'sale invoice status
                End If
            Next j

            ' With Worksheets(sheetNo).Range("AB7").Interior 'inv_status_note = Z7
            '     .ColorIndex = indexColor
            ' End With

            ' With Worksheets(sheetNo).Range("AB7").Font
            '     .Bold = False
            '     .ColorIndex = 2
            '     .Name = "Roboto"
            '     .Size = 12
            ' End With
            '******* End Update status color ***********
            
            ' Worksheets(sheetNo).Tab.ColorIndex = indexColor
            clearReceivePayment (obj)
            Sheets("IncomeData").select
            incomeId = ActiveSheet.Cells(Rows.Count, "B").End(xlUp).Row
            ActiveSheet.Range("B" & incomeId & ":" & "W" & incomeId).Select
            MsgBox "Receive payment successful saved."
        Else
            exit sub
        End If
    End If
End Sub

Sub updateStatusColorReceivePayment()
    Dim indexColor AS Integer
    Dim status AS Integer
    Dim rp AS Worksheet

    Set rp = Sheets("ReceivePayment")
    status = rp.Range("c_rp_status").Value
    If status = -1 Then
        indexColor = 1
    ElseIf status = 1 Then
        indexColor = 3
    ElseIf status = 2 Then
        indexColor = 43
    ElseIf status = 3 Then
        indexColor = 44
    End If

    With rp.Range("rp_status_note").Interior 'inv_status_note = Z7
        .ColorIndex = indexColor
    End With

    With rp.Range("rp_status_note").Font
        .Bold = False
        .ColorIndex = 2
        .Name = "Roboto"
        .Size = 12
    End With
End Sub

Function updateBalanceSalesInvoice(obj)
    Dim LastRow, lastCol, i As Long
    Dim ws,rp As Worksheet
    Dim invoiceNo AS Integer 
    Dim totalAmountPaid,totalBalance,totalAmountDue,totalAmountPaidBefore AS Double
    Dim statusInvoice AS Integer

    Set ws = Sheets("SaleInvoiceData")
    Set rp = Sheets("ReceivePayment")

    invoiceNo       = rp.Range("c_rp_invoice_no").Value
    totalAmountDue  = rp.Range("rp_amount_due").Value
    totalAmountPaid = rp.Range("rp_total_amount_paid").Value
    totalBalance    = rp.Range("rp_total_balance").Value
    totalAmountPaidBefore = rp.Range("rp_amount_paid_befor").Value

    'Sales Invoice Status=> -1 = Edit, 1  = issue, 2  = fullfilied ,3  = partial
    If totalAmountPaid = totalAmountDue Then
        statusInvoice = 2
    ElseIf totalAmountPaid < totalAmountDue Then
        statusInvoice = 3
    Else
        statusInvoice = 1
    End If

    LastRow = ws.Cells(Rows.Count, "B").End(xlUp).Row 
    lastCol = ws.Cells(6, Columns.Count).End(XlToLeft).column 'start from row 6 column B
 
    For i = 6 To LastRow
        If ws.Cells(i, 2).Value = invoiceNo*1 Then
            'ws.Rows(i).EntireRow.copy
            ws.Cells(i, 14).Value = totalAmountPaid + totalAmountPaidBefore
            ws.Cells(i, 15).Value = totalBalance
            ws.Cells(i, 17).Value = statusInvoice
        End If
    Next i
End Function

Function clearReceivePayment(obj)
    ActiveSheet.Range("c_rp_current_date").Value = ""
    ActiveSheet.Range("c_rp_invoice_no").Value = ""
    ActiveSheet.Range("c_rp_amount_kh_paid").Value = ""
    ActiveSheet.Range("c_rp_amount_en_paid").Value = ""
    ActiveSheet.Range("c_rp_discount").Value = ""
    'ActiveSheet.Range("rp_recipient_option").Value = ""
    ActiveSheet.Range("c_rp_receipt_no").Value = ActiveSheet.Range("c_rp_receipt_no").Value + 1
End Function

Sub copyReceivePayment()
    Sheets("ReceivePayment").Range("Print_Area").Copy
End Sub

Sub CurrentDate()
    ActiveSheet.Range("c_rp_current_date").Value = Format(Now(), "mm/dd/yyyy")
End Sub

Sub ExchangeRateReceivePayment()
    ActiveSheet.Range("c_rp_exchange_rate").Value = Sheets("NBC_Exchange_Rate").Range("ExchangeRateToday").Value
End Sub