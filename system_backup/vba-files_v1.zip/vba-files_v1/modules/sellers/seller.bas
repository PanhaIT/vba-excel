Attribute VB_Name = "mdlCustomer"

